$(document).ready(function(){
	getDatabases();
});

function getDatabases() {
	$.ajax({
		type : 'get',
		url : "/v1/datasets/databases",
		dataType : 'json',
		beforeSend : function(xhr){
			xhr.setRequestHeader("Content-type","application/json");
		},
		error: function(xhr, status, error){
			alert(error);
		},
		success : function(data){
 			$('#database').empty();
 			$('#database').on('change', function() {
				getTables(this.value);
			});
			$('#database').append("<option value=''>select database</option>");
			for( i = 0 ; i < data.length ; i++ ) {
 				$('#database').append("<option value='"+data[i]+"')\">"+data[i]+"</option>");
			}
		},
	});
}

function getTables(database) {
	if ( database == '' ) return;
	$.ajax({
		type : 'get',
		url : "/v1/datasets/tables?database="+database,
		dataType : 'json',
		beforeSend : function(xhr){
			xhr.setRequestHeader("Content-type","application/json");
		},
		error: function(xhr, status, error){
			alert(error);
		},
		success : function(data){
			$('#table').empty();
			$('#table').append("<option value=''>select table</option>");
 			$('#table').on('change', function() {
				if ( this.value != '' )
					getTableColumns(database, this.value);
			});
			for( i = 0 ; i < data.length ; i++ ) {
				$('#table').append("<option value='"+data[i]+"')\">"+data[i]+"</option>");
			}
		},
	});
}

function getTableColumns(database, table) {
	if ( database == '' ) return;
	$.ajax({
		type : 'get',
		url : "/v1/datasets/"+database+"/"+table+"/columns",
		dataType : 'json',
		beforeSend : function(xhr){
			xhr.setRequestHeader("Content-type","application/json");
		},
		error: function(xhr, status, error){
			alert(error);
		},
		success : function(data){
			$('#pk').empty();
			for( i = 0 ; i < data.length ; i++ ) {
				$('#pk').append("<option value='"+data[i].field+"'>"+data[i].field+(data[i].key=='PRI'?"(PK)":"")+"</option>");
			}
		},
	});
}

function getDatasetInfo() {

	var database = $('#database option:selected').val();
	var table = $('#table option:selected').val();
	var pk  = $('#pk').val();

	if ( pk == '' ) {
		alert('Please Enter PK');
		return false;
	}

	$.ajax({
		type : 'get',
		url : "/v1/datasets/"+database+"/"+table+"/"+pk,
		dataType : 'json',
		beforeSend : function(xhr){
			xhr.setRequestHeader("Content-type","application/json");
		},
		error: function(xhr, status, error){
			alert('Check PK column');
		},
		success : function(data){
			$('#dataset_sql').html(data.dataset_original_sql);
			$('#start_pk').html(data.start_pk);
			$('#end_pk').html(data.end_pk);
			$('#dataset_id').html(data.dataset_id);
			$('#original_dataset_hash').html(data.dataset_hash);
		},
	});
}

function storeDatasetInfo() {

	var database = $('#database option:selected').val();
	var table = $('#table option:selected').val();
	var pk  = $('#pk').val();

	if ( pk == '' ) {
		alert('Please Enter PK');
		return false;
	}

	$.ajax({
		type : 'post',
		url : "/v1/datasets/dataset/"+database+"/"+table+"/"+pk,
		dataType : 'json',
		beforeSend : function(xhr){
			xhr.setRequestHeader("Content-type","application/json");
		},
		error: function(xhr, status, error){
			alert(status);
			alert('Error occurred');
		},
		success : function(data){
			//$('#dataset_sql').html('');
			//$('#start_pk').html('');
			//$('#end_pk').html('');
			//$('#dataset_id').html('');
			//$('#original_dataset_hash').html('');

			alert('Completed');
		},
	});
}

function getDatasetIds() {
	
	$.ajax({
		type : 'get',
		url : "/v1/datasets/datasets/id",
		dataType : 'json',
		beforeSend : function(xhr){
			xhr.setRequestHeader("Content-type","application/json");
		},
		error: function(xhr, status, error){ 
			alert(error); 
		},
		success : function(data){
			$('#datasetList').html('');
			for( i = 0 ; i < data.length/2 ; i++ ) {
				if ( i == 0 )
					$('#datasetList').append('<tr><th scope="row" rowspan="'+(data.length)+'">Dstaset ID</th><td id=dataset_id'+(i*2)+'></td><td id=dataset_id'+(i*2+1)+'></td></tr');
				else
					$('#datasetList').append('<tr><td id=dataset_id'+(i*2)+'></td><td id=dataset_id'+(i*2+1)+'></td></tr>');
			}
			for( i = 0 ; i < data.length ; i++ ) {
				$('#dataset_id'+(i)).html('<a href="javascript:getStoredDataset(\''+data[i]+'\')">'+data[i]+'</a>');
			}

			initStoreDatasetSection();
			initVerifySection();
		},
	});
}

function getStoredDataset(dataset_id) {

	$.ajax({
                type : 'get',
                url : "/v1/datasets/dataset/"+dataset_id,
                dataType : 'json',
                beforeSend : function(xhr){
                        xhr.setRequestHeader("Content-type","application/json");
                },
                error: function(xhr, status, error){
                        alert(error);
                },
                success : function(data){
                        $('#selectedDatasetID').html(data.dataset_id);
                        $('#selectedDatasetSQL').html(data.dataset_sql);
                        $('#verifyBtn').unbind('click');
                        $('#verifyBtn').click(function(){verifyDataset(dataset_id)});

			initVerifySection();
                },
        });

}

function verifyDataset(dataset_id) {

        $.ajax({
                type : 'get',
                url : "/v1/datasets/dataset/verification/"+dataset_id,
                dataType : 'json',
                beforeSend : function(xhr){
                        xhr.setRequestHeader("Content-type","application/json");
                },
                error: function(xhr, status, error){
                        alert(error);
                },
                success : function(data){
                        $('#dataset_hash').html(data.dataset_hash);
                        $('#blockchain_hash').html(data.blockchain_hash);
                        $('#verified').html(data.verified==1?'identical':'different');
                },
        });

}

function initStoreDatasetSection() {

	$('#selectedDatasetID').html('');
	$('#selectedDatasetSQL').html('');
	$('#verifyBtn').unbind('click');
}  

function initVerifySection() {
	$('#dataset_hash').html('');
	$('#blockchain_hash').html('');
	$('#verified').html('');
}
